package src.handler;

import java.io.*;

public class PhpExecutor {
    public static void executePhpFile(File file, OutputStream out) throws IOException {
        ProcessBuilder processBuilder = new ProcessBuilder("php -r", file.getAbsolutePath());
        processBuilder.redirectErrorStream(true);

        try {
            Process process = processBuilder.start();
            try (BufferedReader phpOutput = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                StringBuilder responseContent = new StringBuilder();
                String line;

                while ((line = phpOutput.readLine()) != null) {
                    responseContent.append(line).append("\n");
                }

                process.waitFor();
                sendHttpResponse(out, responseContent.toString());
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                sendErrorResponse(out, "500 Internal Server Error");
            }
        } catch (IOException e) {
            sendErrorResponse(out, "500 Internal Server Error");
        }
    }

    private static void sendErrorResponse(OutputStream out, String status) throws IOException {
        String response = "HTTP/1.1 " + status + "\r\n" +
                          "Content-Type: text/plain\r\n" +
                          "\r\n" +
                          status;
        out.write(response.getBytes());
        out.flush();
    }

    private static void sendHttpResponse(OutputStream out, String content) throws IOException {
        String response = """
                          HTTP/1.1 200 OK\r
                          Content-Type: text/html\r
                          \r
                          """ +
                          content;
        out.write(response.getBytes());
        out.flush();
    }
}
