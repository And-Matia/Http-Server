package src.handler;

import java.io.*;
import java.net.Socket;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import src.config.Config;

public class RequestHandler {
    private final Socket clientSocket;
    private final String rootDirectory;
    private final boolean phpState;

    public RequestHandler(Socket clientSocket, String rootDirectory, boolean phpState) {
        this.clientSocket = clientSocket;
        this.rootDirectory = rootDirectory;
        this.phpState = phpState;
    }

    public void handle() throws IOException {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
             OutputStream out = clientSocket.getOutputStream()) {
    
            String requestLine = in.readLine();
            if (requestLine != null) {
                String[] tokens = requestLine.split(" ");
                String method = tokens[0];
                String requestedFile = tokens[1].equals("/") ? "/" : tokens[1];
                File file = new File(rootDirectory + requestedFile);
    
                System.out.printf("[%s] %s -> %s%n", method, requestedFile, file.getPath());
    
                switch (method) {
                    case "GET" -> handleGetRequest(file, out);
                    case "POST" -> handlePostRequest(file, in, out);
                    case "PUT" -> handlePutRequest(file, in, out);
                    case "DELETE" -> handleDeleteRequest(file, out);
                    default -> sendMethodNotAllowed(out);
                }
            }
        }
    }

    public boolean isAPhpFile(String file) {
        if (file == null) return false;

        int queryIndex = file.indexOf("?");
        if (queryIndex != -1) {
            file = file.substring(0, queryIndex);
        }

        return file.toLowerCase().endsWith(".php");
    }

    private void handleGetRequest(File requestedFile, OutputStream out) throws IOException {
        if (requestedFile.exists()) {
            if (requestedFile.isDirectory()) {
                File indexFile = new File(requestedFile, Config.getDefaultFile());
                if (indexFile.exists()) {
                    if (isAPhpFile(requestedFile.getName()) && phpState) {
                        new PhpHandler(indexFile, out).handle();
                    }else {
                        sendFile(indexFile, out);
                    }
                } else {
                    listDirectory(requestedFile, out);
                }
            } else if (isAPhpFile(requestedFile.getName()) && phpState) {
                new PhpHandler(requestedFile, out).handle();
            } else {
                sendFile(requestedFile, out);
            }
        } else {
            sendNotFound(out);
        }
    }

    private void handlePostRequest(File file, BufferedReader in, OutputStream out) throws IOException {
        if (!file.exists()) {
            sendNotFound(out);
            return;
        }

        StringBuilder headers = new StringBuilder();
        String line;
        while ((line = in.readLine()) != null && !line.isEmpty()) {
            headers.append(line).append("\n");
        }

        int contentLength = getContentLength(headers.toString());

        char[] body = new char[contentLength];
        in.read(body);
        String postData = new String(body);
        Map<String, String> postParams = parsePostData(postData);

        String response = """
                          HTTP/1.1 200 OK\r
                          Content-Type: application/json\r
                          \r
                          { "status": "success", "data": """ + postParams.toString() + " }";
        out.write(response.getBytes(StandardCharsets.UTF_8));
        out.flush();
    }

    private void handlePutRequest(File file, BufferedReader in, OutputStream out) throws IOException {
        if (file.exists() && file.isDirectory()) {
            sendMethodNotAllowed(out);
            return;
        }
    
        if (!file.exists()) {
            file.createNewFile();
        }
    

        StringBuilder headers = new StringBuilder();
        String line;
        while ((line = in.readLine()) != null && !line.isEmpty()) {
            headers.append(line).append("\n");
        }
    
        int contentLength = getContentLength(headers.toString());
        char[] body = new char[contentLength];
        in.read(body);
    
        String jsonBody = new String(body);
        String content = extractContentFromJson(jsonBody);
    
        try (FileWriter fileWriter = new FileWriter(file)) {
            fileWriter.write(content);
            String response = """
                              HTTP/1.1 200 OK\r
                              Content-Type: application/json\r
                              \r
                              {"message":"Fichier mis \u00e0 jour avec succ\u00e8s !"}""";
            out.write(response.getBytes(StandardCharsets.UTF_8));
            out.flush();
        } catch (IOException e) {
            sendInternalServerError(out);
        }
    }
    
    private String extractContentFromJson(String json) {
        int start = json.indexOf("content\":\"") + 10;
        int end = json.indexOf("\"}", start);
        return json.substring(start, end);
    }

    private void handleDeleteRequest(File file, OutputStream out) throws IOException {
        if (file.exists()) {
            if (file.delete()) {
                out.write("HTTP/1.1 200 OK\r\n\r\nResource deleted successfully".getBytes(StandardCharsets.UTF_8));
                out.flush();
            } else {
                sendInternalServerError(out);
            }
        } else {
            sendNotFound(out);
        }
    }

    private void listDirectory(File directory, OutputStream out) throws IOException {
        String[] files = directory.list();
        try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(out, StandardCharsets.UTF_8))) {
            writer.write("HTTP/1.1 200 OK\r\n");
            writer.write("Content-Type: text/html\r\n");
            writer.write("\r\n");

            writer.write("<html><body><h1>Index of " + directory.getPath() + "</h1>");
            writer.write("<ul>");
            assert files != null;
            for (String fileName : files) {
                File file = new File(directory, fileName);
                if (file.isDirectory()) {
                    writer.write("<li><a href=\"" + fileName + "/\">" + fileName + "/</a></li>");
                } else {
                    writer.write("<li><a href=\"" + fileName + "\">" + fileName + "</a></li>");
                }
            }
            writer.write("</ul>");
            writer.write("</body></html>");
            writer.flush();
        }
    }

    private void sendFile(File file, OutputStream out) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(out, StandardCharsets.UTF_8));
             BufferedReader fileReader = new BufferedReader(new FileReader(file))) {

            writer.write("HTTP/1.1 200 OK\r\n");
            writer.write("Content-Type: " + getContentType(file) + "\r\n");
            writer.write("\r\n");
            writer.flush();

            String line;
            while ((line = fileReader.readLine()) != null) {
                writer.write(line + "\r\n");
            }
            writer.flush();
        }
    }

    private void sendNotFound(OutputStream out) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(out, StandardCharsets.UTF_8))) {
            writer.write("HTTP/1.1 404 Not Found\r\n");
            writer.write("Content-Type: text/html\r\n");
            writer.write("\r\n");
            writer.write("<html><body><h1>404 - Page Not Found</h1></body></html>");
            writer.flush();
        }
    }

    private void sendMethodNotAllowed(OutputStream out) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(out, StandardCharsets.UTF_8))) {
            writer.write("HTTP/1.1 405 Method Not Allowed\r\n");
            writer.write("Content-Type: text/html\r\n");
            writer.write("\r\n");
            writer.write("<html><body><h1>405 - Method Not Allowed</h1></body></html>");
            writer.flush();
        }
    }

    private void sendInternalServerError(OutputStream out) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(out, StandardCharsets.UTF_8))) {
            writer.write("HTTP/1.1 500 Internal Server Error\r\n");
            writer.write("Content-Type: text/html\r\n");
            writer.write("\r\n");
            writer.write("<html><body><h1>500 - Internal Server Error</h1></body></html>");
            writer.flush();
        }
    }

    private String getContentType(File file) {
        String fileName = file.getName().toLowerCase();
        if (fileName.endsWith(".html") || fileName.endsWith(".htm")) {
            return "text/html";
        } else if (fileName.endsWith(".css")) {
            return "text/css";
        } else if (fileName.endsWith(".js")) {
            return "application/javascript";
        } else if (fileName.endsWith(".jpg") || fileName.endsWith(".jpeg")) {
            return "image/jpeg";
        } else if (fileName.endsWith(".png")) {
            return "image/png";
        } else if (fileName.endsWith(".gif")) {
            return "image/gif";
        } else {
            return "application/octet-stream";
        }
    }

    private int getContentLength(String headers) {
        for (String header : headers.split("\n")) {
            if (header.toLowerCase().startsWith("content-length")) {
                return Integer.parseInt(header.split(":")[1].trim());
            }
        }
        return 0;
    }

    private Map<String, String> parsePostData(String postData) {
        Map<String, String> postParams = new HashMap<>();
        String[] pairs = postData.split("&");
        for (String pair : pairs) {
            String[] keyValue = pair.split("=");
            String key = URLDecoder.decode(keyValue[0], StandardCharsets.UTF_8);
            String value = keyValue.length > 1 ? URLDecoder.decode(keyValue[1], StandardCharsets.UTF_8) : "";
            postParams.put(key, value);
        }
        return postParams;
    }
}
