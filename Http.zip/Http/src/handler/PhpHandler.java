package src.handler;

import java.io.*;

public class PhpHandler {

    private final File phpFile;
    private final OutputStream out;

    public PhpHandler(File phpFile, OutputStream out) {
        this.phpFile = phpFile;
        this.out = out;
    }

    public void handle() throws IOException {
        executePhpFile();
    }

    private void executePhpFile() throws IOException {
        ProcessBuilder pb = new ProcessBuilder("php", phpFile.getAbsolutePath());
        Process phpProcess = pb.start();

        try (BufferedReader phpOutput = new BufferedReader(new InputStreamReader(phpProcess.getInputStream()))) {
            String content = readProcessOutput(phpOutput);
            sendHttpResponse(content);
        } catch (IOException e) {
            sendErrorResponse("500 Internal Server Error", "PHP execution failed: " + e.getMessage());
        }
    }

    private String readProcessOutput(BufferedReader reader) throws IOException {
        StringBuilder response = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            response.append(line).append("\n");
        }
        return response.toString();
    }

    private void sendHttpResponse(String content) throws IOException {
        String response = """
                          HTTP/1.1 200 OK\r
                          Content-Type: text/html\r
                          \r
                          """ + content;
        out.write(response.getBytes());
        out.flush();
    }

    private void sendErrorResponse(String status, String message) throws IOException {
        String errorResponse = """
                               HTTP/1.1 %s\r
                               Content-Type: text/html\r
                               \r
                               <html><body><h1>%s</h1></body></html>
                               """.formatted(status, message);
        out.write(errorResponse.getBytes());
        out.flush();
    }
}
