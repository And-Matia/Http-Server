package src.config;

import java.io.*;
import java.util.Properties;

public class Config {
    private static final Properties properties = new Properties();

    static {
        try (InputStream input = new FileInputStream("app.conf")) {
            properties.load(input);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public static String get(String key) {
        return properties.getProperty(key);
    }

    public static int getPort() {
        return Integer.parseInt(properties.getProperty("server.port", "8080"));
    }

    public static String getBaseDirectory() {
        return properties.getProperty("server.baseDirectory", ".");
    }

    public static String getDefaultFile() {
        return properties.getProperty("server.defaultFile", "index.php");
    }

    public static boolean getPhpState() {
        return Boolean.parseBoolean(properties.getProperty("server.phpState", "false"));
    }
}
