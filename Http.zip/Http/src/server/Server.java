package src.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import src.config.Config;
import src.handler.RequestHandler;

public class Server {
    public static void main(String[] args) {
        String fileName = Config.getBaseDirectory(); 
        int port = Config.getPort();            
        boolean phpState = Config.getPhpState();  // Ajout de phpState

        if (args.length >= 1) {
            fileName = args[0]; 
        }
        if (args.length >= 2) {
            try {
                port = Integer.parseInt(args[1]);
            } catch (NumberFormatException e) {
                System.err.println("Warning: Invalid port number. Using default port: " + port);
            }
        }

        System.out.println("Starting server with:");
        System.out.println("  - File or Directory: " + fileName);
        System.out.println("  - On Port: " + port);
        System.out.println("  - PHP State: " + (phpState ? "Enabled" : "Disabled"));

        ExecutorService threadPool = Executors.newCachedThreadPool();
        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("Server is running...");

            while (true) {
                Socket clientSocket = serverSocket.accept();
                String finalFileName = fileName;
                boolean finalPhpState = phpState;  // Passer phpState à RequestHandler
                threadPool.submit(() -> {
                    try {
                        new RequestHandler(clientSocket, finalFileName, finalPhpState).handle();
                    } catch (IOException e) {
                        System.err.println("Error handling client: " + e.getMessage());
                    }
                });
            }
        } catch (IOException e) {
            System.err.println("Server error: " + e.getMessage());
        }
    }
}
