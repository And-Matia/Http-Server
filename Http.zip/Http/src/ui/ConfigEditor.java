package src.ui;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.*;

public class ConfigEditor extends JFrame {
    private JTextField portField;
    private JTextField baseDirectoryField;
    private JTextField defaultFileField;
    private JRadioButton phpStateEnabled;
    private JRadioButton phpStateDisabled;
    private JButton saveButton;

    public ConfigEditor() {
        setTitle("Configuration Editor");
        setLayout(new GridLayout(5, 2, 10, 10));

        add(new JLabel("Server Port:"));
        portField = new JTextField("8080");
        add(portField);

        add(new JLabel("Base Directory:"));
        baseDirectoryField = new JTextField("public");
        add(baseDirectoryField);

        add(new JLabel("Default File:"));
        defaultFileField = new JTextField("index.html");
        add(defaultFileField);

        add(new JLabel("PHP State:"));
        JPanel phpStatePanel = new JPanel();
        phpStateEnabled = new JRadioButton("Enabled", true);
        phpStateDisabled = new JRadioButton("Disabled", false);
        ButtonGroup phpStateGroup = new ButtonGroup();
        phpStateGroup.add(phpStateEnabled);
        phpStateGroup.add(phpStateDisabled);
        phpStatePanel.add(phpStateEnabled);
        phpStatePanel.add(phpStateDisabled);
        add(phpStatePanel);

        saveButton = new JButton("Save Configuration");
        saveButton.addActionListener(new SaveButtonListener());
        add(saveButton);

        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private class SaveButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String port = portField.getText();
            String baseDirectory = baseDirectoryField.getText();
            String defaultFile = defaultFileField.getText();
            boolean phpState = phpStateEnabled.isSelected();

            try (FileWriter writer = new FileWriter("app.conf")) {
                writer.write("server.port=" + port + "\n");
                writer.write("server.baseDirectory=" + baseDirectory + "\n");
                writer.write("server.defaultFile=" + defaultFile + "\n");
                writer.write("server.phpState=" + phpState + "\n");

                JOptionPane.showMessageDialog(ConfigEditor.this, "Configuration saved successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(ConfigEditor.this, "Error saving configuration!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ConfigEditor editor = new ConfigEditor();
            editor.setVisible(true);
        });
    }
}
